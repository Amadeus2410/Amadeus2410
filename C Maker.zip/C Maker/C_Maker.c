#include <stdio.h>

int main ()
{

int var, var_value1;
char var_name, var_value2[20], var_result[20];
float var_value3;

int act;

printf("Please choose data type");
printf("\n[ 1 ] Integer\n[ 2 ] Character\n[ 3 ] Float");
printf("\nOption: ");
scanf("%d", &var);

printf("\nEnter the name of variable: ");
scanf(" %c", &var_name);

switch(var){
    case 1: printf("\nEnter the value (0 if empty): ");
            scanf("%d", &var_value1);
            break;
    case 2: printf("\nEnter the value (0 if empty): ");
            scanf("%c", var_value2);
            break;
    case 3: printf("\nEnter the value (0 if empty): ");
            scanf("%f", &var_value3);
            break;}

printf("\nPlease enter action: ");
printf("\n[ 1 ] Printf Output\n[ 2 ] Scan Input\n");
printf("\nOption: ");
scanf("%d", &act);

printf("\nRESULT:");
printf("\n========================================================================\n\n");
printf("#include <stdio.h>\nint main(){\n");

if(var == 1){printf("int ");}
else if(var == 2){printf("char ");}
else{printf("float ");}

if(var_value1 == 0 || var_value2 == '0' || var_value3 == 0.0){printf("%c ;\n", var_name);}
else{if(var == 1){printf("%c = %d;\n", var_name, var_value1);}
        else if(var == 2){printf("%c = '%c' ;\n", var_name, var_value2);}
        else{printf("%c = %f ;\n", var_name, var_value3);}}

printf("printf(");
    if(act == 1){
        if(var == 1){printf("\"%\%\d\", ");}
        else if(var == 2){printf("\"%\%\c\", ");}
        else{printf("\"%\%\f\", ");}}

printf(" %c );\nreturn 0;}", var_name);

printf("\n");
printf("\n========================================================================\n");
return 0;
}
